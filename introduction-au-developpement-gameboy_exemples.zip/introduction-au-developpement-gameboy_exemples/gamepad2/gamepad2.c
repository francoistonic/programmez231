#include <stdio.h>
#include <gb/gb.h>

void main(void) {
    UINT8 prev_keys = 0;
    UINT8 keys;

    printf("Press A or B\n");

    while (1) {
        keys = joypad();

        if (keys & J_A && !(prev_keys & J_A)) {
            printf("A pressed\n");
        }
        if (!(keys & J_A) && prev_keys & J_A) {
            printf("A released\n");
        }

        if (keys & J_B && !(prev_keys & J_B)) {
            printf("B pressed\n");
        }
        if (!(keys & J_B) && prev_keys & J_B) {
            printf("B released\n");
        }

        prev_keys = keys;
        wait_vbl_done();
    }
}
