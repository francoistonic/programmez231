Compilation des exemples
========================

Pour compiler les exemples, vous devrez d'abord avoir installé SDCC comme
indiqué dans l'article. Ensuite tout dépend de votre OS.


Instructions pour Linux
-----------------------

Pour Linux, vous aurez besoin de GNU Make et de Git (en plus de SDCC et de ses
bibliothèques), pour les installer sous Debian / Ubuntu, utilisez la commande
suivante :

    sudo apt install build-essential git

En suite rendez-vous dans le dossier de l'un des exemples :

    cd hello/

Puis téléchargez et compilez gbdk-n :

    make gbdk-n-lib

Enfin compilez l'exemple à l'aide de la commande suivante :

    make


Instructions pour Windows
-------------------------

Sous Windows, commencez par vous rendre dans le dossier contenant un exemple,
puis ouvrez-y un terminal.

Puis téléchargez gbdk-n dans le dossier à l'aide de Git :

    git clone https://github.com/flozz/gbdk-n.git

(si vous n'avez pas git, rendez-vous à l'adresse ci-dessus, téléchargez le zip,
puis décompressez-le dans le dossier. Il vous faudra renommer le dossier
"gbdk-n-master" en "gbdk-n")

Une fois ceci fait, exécutez l'une des commandes suivantes suivant votre
situation.

Si vous utilisez Git Bash:

    ./Make.bat

Si vous utilisez CMD.EXE:

    Make


Licence
-------

Les exemples et les scripts de compilation de cet article sont placés sous la
licence WTFPL 2.0 (http://www.wtfpl.net/about/).

Vous êtes libres de les copier et de les réutiliser comme bon vous semble.


Plus de ressources
------------------

Vous trouverez plus de ressources aux adresses suivantes :

* https://blog.flozz.fr/2018/10/01/developpement-gameboy-1-hello-world/
* https://github.com/gbdev/awesome-gbdev
* https://www.youtube.com/channel/UCMMhSfBStEti-Lqzs30HYWw/videos

