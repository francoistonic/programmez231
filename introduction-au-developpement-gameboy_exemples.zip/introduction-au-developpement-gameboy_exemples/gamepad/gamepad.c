#include <stdio.h>
#include <gb/gb.h>

void main(void) {
    printf("Press START\n");
    waitpad(J_START);
    printf("Ok...\n");

    printf("Now press A or B\n");
    UINT8 keys = waitpad(J_A | J_B);
    if (keys & J_A) {
        printf("You pressed A!\n");
    }
    if (keys & J_B) {
        printf("You pressed B!\n");
    }
}
