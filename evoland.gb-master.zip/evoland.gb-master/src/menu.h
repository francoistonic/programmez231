#ifndef _MENU_H
#define _MENU_H

void menu_main();

#endif
