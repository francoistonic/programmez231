#ifndef _MESSAGES_H
#define _MESSAGES_H

extern const char* MSG_0;
extern const char* MSG_1;
extern const char* MSG_2;
extern const char* MSG_3;
extern const char* MSG_4;
extern const char* MSG_5;
extern const char* MSG_6;

#endif
