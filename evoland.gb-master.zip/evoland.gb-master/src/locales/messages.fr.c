//                  |--------------------|
const char* MSG_0 = "Debloque :\n"
                    "Direction : droite\n"
                    "\n"

                    "On dirait qu'il y a\n"
                    "un coffre par la.\0";

//                  |--------------------|
const char* MSG_1 = "Debloque :\n"
                    "Direction : gauche\n"
                    "\n"

                    "Il faut bien varier\n"
                    "les plaisirs.\0";

//                  |--------------------|
const char* MSG_2 = "Debloque :\n"
                    "Mouvement 2D\n"
                    "\n"

                    "Ca reste un peu\n"
                    "limite...\0";

//                  |--------------------|
const char* MSG_3 = "Debloque :\n"
                    "Scrolling\n"
                    "\n"

                    "Enfin, vous voyez ou\n"
                    "vous allez !\0";

//                  |--------------------|
const char* MSG_4 = "Debloque :\n"
                    "Effets sonores\n"
                    "\n"

                    "C'est tout de suite\n"
                    "plus vivant !\0";

//                  |--------------------|
const char* MSG_5 = "Debloque :\n"
                    "Scrolling homogene\n"
                    "\n"

                    "Ca vous evitera un\n"
                    "mal de tete.\0";

//                  |--------------------|
const char* MSG_6 = "Debloque : Epee\n"
                    "\n"
                    "\n"

                    "Vous pouvez\n"
                    "maintenant tuer les\n"
                    "monstres, et couper\n"

                    "des buissons !\0";
