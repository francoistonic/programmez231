//                  |--------------------|
const char* MSG_0 = "You got\n"
                    "Right Direction\n"
                    "\n"

                    "There seems to be\n"
                    "some chest to open\n"
                    "this way.\0";

//                  |--------------------|
const char* MSG_1 = "You got\n"
                    "Left Direction\n"
                    "\n"

                    "Always going right\n"
                    "is boring!\0";

//                  |--------------------|
const char* MSG_2 = "You got\n"
                    "2D Mouvement\n"
                    "\n"

                    "That's good, you\n"
                    "can't go anywhere\n"
                    "else anyway.\0";

//                  |--------------------|
const char* MSG_3 = "You got\n"
                    "Basic Scrolling\n"
                    "\n"

                    "You want to see\n"
                    "where you're\n"
                    "heading, right?\0";

//                  |--------------------|
const char* MSG_4 = "You got\n"
                    "Sounds FX\n"
                    "\n"

                    "The game is much\n"
                    "more alive this way.\0";

//                  |--------------------|
const char* MSG_5 = "You got \n"
                    "Smoother Scrolling\n"
                    "\n"

                    "Will save you some\n"
                    "headache.\0";

//                  |--------------------|
const char* MSG_6 = "You got a Sword\n"
                    "\n"
                    "\n"

                    "Now you can kill the\n"
                    "evil monsters and\n"
                    "cut down bushes\0";
