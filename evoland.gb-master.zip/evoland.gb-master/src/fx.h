#ifndef _FX_H
#define _FX_H

void fx_bg_fade_in();
void fx_bg_fade_out();

#endif
