The files of this folder are the property of Shiro Games, you are not allowed to reproduce them with modified versions of Evoland.gb nor to use them in your own projects.
