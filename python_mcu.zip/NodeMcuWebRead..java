import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class NodeMcuWebRead {
  public static void main(String[] args) throws IOException {	 
    URL url = new URL("http://192.168.1.138");
    BufferedReader in = new BufferedReader(
    new InputStreamReader(url.openStream()));

    String inputLine;
    float temperature = (float)0.0;
    int lineNb = 0;
    while ((inputLine = in.readLine()) != null) {
  	 if (lineNb == 4) {
  	   inputLine = inputLine.replaceAll("\\s+","");
  	   temperature = Float.parseFloat(inputLine);
  	   System.out.println(temperature);
  	   break;
  	 }
  	 lineNb++;
    }
    in.close();
  }
}