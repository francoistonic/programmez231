from machine import ADC

adc = ADC(0)  #assigne la broche analogique

def temperature():
    value = adc.read()
    return value/3.95

celsius_temp = temperature()
print(celsius_temp)
print(round(celsius_temp, 1))