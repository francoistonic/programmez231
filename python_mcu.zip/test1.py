import sys
print(sys.platform+ " " + sys.version)
