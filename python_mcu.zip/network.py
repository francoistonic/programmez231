import network
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
print('network config:', sta_if.ifconfig())