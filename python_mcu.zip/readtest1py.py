import os
os.listdir()
print(open('test1.py').read())
os.remove('test1.py')
os.listdir()