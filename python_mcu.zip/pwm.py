from machine import Pin, PWM
import time

from machine import Pin
from time import sleep

ledblue  = Pin(16, Pin.OUT)  #bleu
ledgreen = Pin(5, Pin.OUT)   #vert
ledred   = Pin(4, Pin.OUT)   #rouge
ledred.value(0)
ledgreen.value(0)
ledblue.value(0)


pwm = PWM(Pin(4))
for level in range(0, 1023):
    time.sleep(.01)
    pwm.duty(level)