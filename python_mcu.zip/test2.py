from machine import Pin
from time import sleep

ledblue  = Pin(16, Pin.OUT)  #bleu
ledgreen = Pin(5, Pin.OUT)   #vert
ledred   = Pin(4, Pin.OUT)   #rouge

sleep(1.0)
ledblue.value(0)
sleep(2.0)
ledboard   = Pin(2, Pin.OUT)
ledboard.value(0)
sleep(3.0)

ledred.value(0)
ledgreen.value(0)
ledblue.value(0)

while True:
  ledred.value(not ledred.value())
  sleep(1.0)